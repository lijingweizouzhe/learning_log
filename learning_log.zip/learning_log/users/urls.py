"""为应用程序users定义URL模式"""
from django.urls import path, include, re_path
from django.contrib.auth.views import LoginView

from . import views

# 修改模板路径
# LoginView.template_name = 'users/login.html'

urlpatterns = [
    # 登陆页面
    # path('login/', login, {'template_name': 'users/login.html'}, name = 'login')    旧版本
    path('login/', LoginView.as_view(template_name='users/login.html'), name='login'),

    # 注销
    path('logout/', views.logout_view, name='logout'),  # 这个name是对前面函数的标记，所以html里访问是依据name找函数的

    # 注册
    path('register/', views.register, name='register')
]

