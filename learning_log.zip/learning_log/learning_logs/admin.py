from django.contrib import admin

# Register your models here.
from . import models
# from learning_logs.models import Topic

admin.site.register(models.Topic)
admin.site.register(models.Entry)
