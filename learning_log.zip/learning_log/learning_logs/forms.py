# 不想让用户与管理网站交互，因此我们将使用Django的表单创建工具来创建让用户能够输入数据的页面
from django import forms

from .models import Topic, Entry, Message


# Django的表单分为两种：django.forms.Form和django.forms.ModelForm。
# 前者是一个基础的表单功能，后者是在前者的基础上结合模型所生成的数据表单。
# 数据表单是将模型的字段转换成表单的字段，再从表单的字段生成HTML的元素控件
class TopicForm(forms.ModelForm):  # 在Django中，创建表单的最简单方式是使用ModelForm

    # 可以在类Meta外添加模型外的表单字段

    # 模型与表单设置，模型字段转换成表单字段主要在类Meta中实现
    class Meta:
        """
        最简单的ModelForm版本只包含一个内嵌的Meta类，
        它告诉Django根据哪个模型创建表单， 以及在表单中包含哪些字段
        """

        # 根据模型Topic创建一个表单，绑定模型
        model = Topic

        # 该表单只包含字段text，fields属性用于设置转换字段
        fields = ['text']

        # 让Django不要为字段text生成标签，labels设置HTML元素控件的label标签
        labels = {'text': ''}


class EntryForm(forms.ModelForm):
    class Meta:
        """Meta类指出了表单基于的模型以及要在表单 中包含哪些字段"""

        model = Entry
        fields = ['text']
        labels = {'text': ''}

        # 。小部件（widget）是一个HTML表单元素，如单行文本框、多行文本区域或下拉列表。
        # 通过设置属性widgets ，可覆盖Django选择的默认小部件。
        # 通过让Django使用forms.Textarea ，我们定制了字段'text' 的输入小部件，
        # 将文本区域的宽度设置为80列，而不是默认的40列。这给用户提供了足够的空间，可以 编写有意义的条目。
        widgets = {'text': forms.Textarea(attrs={'cols': 80})}


class MessageForm(forms.ModelForm):
    class Meta:
        model = Message
        fields = ['message']
        labels = {'text': ''}
        widgets = {'text': forms.Textarea(attrs={'cols': 80})}
