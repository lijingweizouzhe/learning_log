from django.urls import path, re_path
from . import views

urlpatterns = [
    # 主页
    path('', views.index, name='index'),

    # 显示所有主题
    path('topics/', views.topics, name='topics'),

    # 特定主题的详细页面
    # ?P<topic_id> 将匹配的值存储到topic_id 中；
    # 而表达式\d+ 与包含在两个斜杆内的任何数字都匹配， 不管这个数字为多少位
    # 发现URL与这个模式匹配时， Django将调用视图函数topic() ， 并将存储在topic_id 中的值作为实参传递给它
    re_path(r'topics/(?P<topic_id>\d+)/', views.topic, name='topic'),

    # 用于添加新主题Topic的网页
    path('new_topic/', views.new_topic, name='new_topic'),

    # 用于添加新条目Entry的页面
    re_path(r'new_entry/(?P<topic_id>\d+)/', views.new_entry, name='new_entry'),

    # 用于编辑条目的页面
    re_path(r'edit_entry/(?P<entry_id>\d+)/', views.edit_entry, name='edit_entry'),

    # 用于留言
    path('leave_a_message/', views.leave_a_message, name='leave_a_message'),
]