from django.shortcuts import render
from django.http import HttpResponseRedirect, Http404  # 服务器上没有请求的资源时，标准的做法是返回404响应
# from django.core.urlresolvers import reverse 旧版本，已更新为下面那行
from django.urls import reverse
from django.contrib.auth.decorators import login_required

# Create your views here.
from .models import Topic, Entry, Message
from .forms import TopicForm, EntryForm, MessageForm


def index(request):
    """学习笔记的主页"""
    return render(request, 'learning_logs/index.html')


# login_required() 的代码检查用户是否已登录，仅当用户已登录时，
# Django才运行topics() 的代码。如果用户未登录，就重定向到登录页面。
# 为实现这种重定向，我们需要修改settings.py，让Django知道到哪里去查找登录页面, 在settings末尾
@login_required
def topics(request):
    """显示所有的主题"""
    # 查询数据库——请求提供Topic对象， 并按属性date_added 对它们进行排序
    # topics = Topic.objects.order_by('date_added')
    # 只允许用户访问自己的主题
    # 用户登录后，request 对象将有一个user 属性，这个属性存储了有关该用户的信息。
    # 代码Topic.objects.filter(owner=request.user) 让Django只从数据库中获
    # 取owner 属性为当前用户的Topic 对象。由于我们没有修改主题的显示方式，因此无需对页面topics的模板做任何修改。
    topics = Topic.objects.filter(owner=request.user).order_by('date_added')

    # 定义了一个将要发送给模板的上下文。
    # 上下文是一个字典， 其中的键是我们将在模板中用来访问数据的名称， 而值是我们要发送给模板的数据。
    # 在这里， 只有一个键—值对， 它包含我们将在网页中显示的一组主题。
    context = {'topics': topics}

    # 创建使用数据的网页时， 除对象request 和模板的路径外， 我们还将变量context 传递给render()
    return render(request, 'learning_logs/topics.html', context)


@login_required
def topic(request, topic_id):  # 第二个参数topic_id是urls.py中正则表达式(?P<topic_id>\d+) 捕获的值
    """显示单个主题及其所有的条目"""
    topic = Topic.objects.get(id=topic_id)

    # 确认请求的主题属于当前用户
    # 收到主题请求后，我 们在渲染网页前检查该主题是否属于当前登录的用户。
    # 如果请求的主题不归当前用户所有，我们就引发Http404异常，让Django返回一个404错误页面。
    if topic.owner != request.user:
        raise Http404

    # 获取与该主题相关联的条目， 并将它们按date_added 排序：
    # date_added 前面的减号指定按降序排列， 即先显示最近的条目。
    entries = topic.entry_set.order_by('-date_added')

    # 将主题和条目都存储在字典context中
    context = {'topic': topic, 'entries': entries}

    return render(request, 'learning_logs/topic.html', context)


@login_required
def new_topic(request):
    """
    添加新主题

    我们导入了HttpResponseRedirect 类，用户提交主题后我们将使用这个类将用户重定向到网页topics 。
    函数reverse() 根据指定的URL模型确定URL， 这意味着Django将在页面被请求时生成URL。 我们还导入了刚才创建的表单TopicForm 。

    创建Web应用程序时， 将用到的两种主要请求类型是GET请求和POST请求。
    对于只是从服务器读取数据的页面， 使用GET请求； 在用户需要通过表单提交信息时， 通常使用POST请求。
    处理所有表单时， 我们都将指定使用POST方法

    函数new_topic() 将请求对象作为参数。
    用户初次请求该网页时， 其浏览器将发送GET请求； 用户填写并提交表单时， 其浏览器将发送POST请求。
    根据请求的类型， 我们可以确定用户请求的是空表单（GET请求） 还是要求对填写好的表单进行处理（POST请求）

    1、首先判断用户的请求方式，不同的请求方式执行不同的程序处理。
    函数new_topic分别对GET（或非POST）和POST请求做了不同的响应处理。
    2、用户在浏览器中访问http://127.0.0.1:8000/new_topic/，等同于向MyDjango发送一个GET请求，
    函数new_topic将表单TopicForm实例化并传递给模板，由模板引擎生成HTML表单返回给用户。
　　3、当用户在网页上输入相关信息后单击"提交"按钮，等同于向MyDjango发送一个POST请求，
    函数new_topic首先获取表单数据对象TopicForm，然后由is_valid()对数据对象TopicForm进行数据验证。
    """

    if request.method != 'POST':  # 页面发送的不是POST请求，说明可能是GET请求或者其他请求，则发送空表单
        # 未提交数据，创建一个新表单，将forms中的表单实例化
        form = TopicForm()
    else:  # 页面发送POST请求，说明请求对填好的表单进行处理
        # POST提交的数据，对数据进行处理
        form = TopicForm(request.POST)  # 用户输入的数据存储在request.POST中，创建一个TopicForm 实例，这样对象form 将包含用户提交的信息。
        if form.is_valid():  # 要将提交的信息保存到数据库， 必须先通过检查确定它们是有效的
            # 将新主题关联到当前用户
            # 我们首先调用form.save()，并传递实参commit=False，这是因为我们先修改新主题，再将其保存到数据库中。
            # 接下来，将新主题的owner 属性设置为当前用户。
            # 最后，对刚定义的主题实例调用save()。现在主题包含所有必不可少的数据，将被成功地保存。
            new_topic = form.save(commit=False)
            new_topic.owner = request.user
            new_topic.save()
            # form.save()  # 如果所有字段都有效， 我们就可调用save()，将表单中的数据写入数据库。

            # 保存数据后，就可离开这个页面了。我们使用reverse()获取页面topics的URL，并将其传递给HttpResponseRedirect()
            # 后者将用户的浏览器重定向到页面topics。在页面topics中，用户将在主题列表中看到他刚输入的主题。
            return HttpResponseRedirect(reverse('learning_logs:topics'))

    # 实例化的form传给前端html
    context = {'form': form}
    return render(request, 'learning_logs/new_topic.html', context)


@login_required
def new_entry(request, topic_id):
    """在特定的主题中添加新条目"""
    topic = Topic.objects.get(id=topic_id)

    if request.method != 'POST':
        # 未提交数据，创建一个空表单
        form = EntryForm()
    else:
        # POST提交的数据,对数据进行处理
        form = EntryForm(data=request.POST)
        if form.is_valid():

            # 调用save()时，我们传递了实参commit=False，让Django创建一个新的条目对象，
            # 并将其存储到new_entry 中，但不将它保存到数据库中(先不提交）
            new_entry = form.save(commit=False)

            # 我们将new_entry的属性topic设置为在这个函数开头从数据库中获取的主题，
            new_entry.topic = topic

            # 然后调用save() ，且不指定任何实参。这将把条目保存到数据库，并将其与正确的主题相关联。
            new_entry.save()

            # 们将用户重定向到显示相关主题的页面。调用reverse() 时，
            # 需要提供两个实参：要根据它来生成URL的URL模式的名称；列表args,其中包含要包含在URL中的 所有实参。
            return HttpResponseRedirect(reverse('learning_logs:topic', args=[topic_id]))

    context = {'topic': topic,'form': form}
    return render(request, 'learning_logs/new_entry.html', context)


@login_required
def edit_entry(request, entry_id):
    """编辑既有条目"""

    # 获取用户要修改的条目对象，以及与该条目相关联的主题
    entry = Entry.objects.get(id=entry_id)
    topic = entry.topic

    if topic.owner != request.user:
        raise Http404

    if request.method != 'POST':
        # 初次请求，使用当前条目填充表单
        # 在请求方法为GET时将执行的if代码块中，我们使用实参instance=entry 创建一个EntryForm实例。
        # 这个实参让Django创建一个表单，并使用既有条目对象中的信息填充它。用户将看到既有的数据，并能够编辑它们。
        form = EntryForm(instance=entry)
    else:
        # POST提交的数据，对数据进行处理
        # 处理POST请求时，我们传递实参instance=entry 和data=request.POST，
        # 让Django根据既有条目对象创建一个表单实例，并根据request.POST中的相关数 据对其进行修改。
        form = EntryForm(instance=entry, data=request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('learning_logs:topic', args=[topic.id]))

    context = {'entry': entry, 'topic': topic, 'form': form}
    return render(request, 'learning_logs/edit_entry.html', context)


def leave_a_message(request):
    """留言"""
    # oder_by('date_added')  顺序
    # oder_by('-date_added') 倒序
    messages = Message.objects.order_by('-date_added')

    if request.method != 'POST':
        # 未提交数据，创建一个空表单
        form = MessageForm()
    else:
        # POST提交的数据,对数据进行处理
        form = MessageForm(data=request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('learning_logs:leave_a_message'))

    context = {'messages': messages, 'form': form}
    return render(request, 'learning_logs/leave_a_message.html', context)
